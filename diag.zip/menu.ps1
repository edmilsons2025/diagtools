﻿# Configuração inicial para garantir suporte a cores e acentos
[console]::InputEncoding = [console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'SilentlyContinue'

function Show-Menu {
    Clear-Host
    Write-Host "======================================================" -ForegroundColor Cyan
    Write-Host "           SISTEMA DE DIAGNÓSTICO POSITIVO            " -ForegroundColor White -BackgroundColor DarkCyan
    Write-Host "======================================================" -ForegroundColor Cyan
    Write-Host " 1. [Coletas] - Bateria e Inventário (BMS Dump)"
    Write-Host " 2. [Testes]  - Performance, Memória e Disco"
    Write-Host " 3. [Softwares]- Downloads de Performance"
    Write-Host " 4. [Android] - Instalar ADB e APKs de Teste"
    Write-Host " Q. Sair"
    Write-Host "------------------------------------------------------"
}

function Executar-Coleta-Bateria {
    Clear-Host
    
    # Ajuste crucial para IEX: Força o salvamento na Área de Trabalho
    $WORKDIR = Join-Path -Path $env:USERPROFILE -ChildPath "Desktop"

    $bios = Get-CimInstance -ClassName Win32_BIOS
    $SN = $bios.SerialNumber
    if ([string]::IsNullOrWhiteSpace($SN)) { $SN = $env:COMPUTERNAME }
    $SN = $SN -replace '[\\/:*?"<>|]', '_'
    $SN = $SN.Trim()

    $TS = Get-Date -Format 'yyyyMMdd_HHmmss'
    $FolderName = "Log_BMS_${SN}_${TS}"
    $TempFolder = Join-Path -Path $WORKDIR -ChildPath $FolderName
    $ZipFile = Join-Path -Path $WORKDIR -ChildPath "${FolderName}.zip"
    $MD = Join-Path -Path $TempFolder -ChildPath "Relatorio_BMS_${SN}.md"
    $JSON = Join-Path -Path $TempFolder -ChildPath "Dados_Estruturados_${SN}.json"
    $EVTX = Join-Path -Path $TempFolder -ChildPath "SystemLog_${SN}.evtx"

    New-Item -ItemType Directory -Path $TempFolder -Force | Out-Null

    Write-Host '=== ENGENHARIA DE SERVIÇOS: COLETA DUMP BMS ===' -ForegroundColor Yellow
    Write-Host "Equipamento: $SN" -ForegroundColor Magenta
    Write-Host "Salvando dados em: $WORKDIR" -ForegroundColor Gray
    Write-Host ''

    Write-Host '[1/6] Gerando Relatórios ACPI (PowerCfg)...' -ForegroundColor Cyan

    $argBattery = "/batteryreport /output `"$TempFolder\battery-report_$SN.html`""
    $argEnergy = "/energy /output `"$TempFolder\energy-report_$SN.html`" /duration 5"

    $p1 = Start-Process -FilePath 'powercfg' -ArgumentList $argBattery -PassThru -WindowStyle Hidden
    $p2 = Start-Process -FilePath 'powercfg' -ArgumentList $argEnergy -PassThru -WindowStyle Hidden

    $sw = [Diagnostics.Stopwatch]::StartNew()
    while (($p1.HasExited -eq $false -or $p2.HasExited -eq $false) -and $sw.Elapsed.TotalSeconds -lt 20) {
        Start-Sleep -Milliseconds 500
    }

    $p1_Status = 'OK'
    $p2_Status = 'OK'

    if (-not $p1.HasExited) { Stop-Process -Id $p1.Id -Force; $p1_Status = 'TIMEOUT' }
    if (-not $p2.HasExited) { Stop-Process -Id $p2.Id -Force; $p2_Status = 'TIMEOUT' }

    Write-Host '[2/6] Analisando histórico temporal (EVTX)...' -ForegroundColor Cyan
    $sysEvents = Get-WinEvent -LogName System -ErrorAction SilentlyContinue | Select-Object TimeCreated
    $primeiroLog = "Desconhecido"
    $maiorGap = 0

    if ($sysEvents -and $sysEvents.Count -gt 1) {
        $primeiroLog = $sysEvents[-1].TimeCreated.ToString('dd/MM/yyyy HH:mm:ss')
        $maxDiff = 0
        for ($i = 0; $i -lt $sysEvents.Count - 1; $i++) {
            $diff = ($sysEvents[$i].TimeCreated - $sysEvents[$i+1].TimeCreated).TotalDays
            if ($diff -gt $maxDiff) { $maxDiff = $diff }
        }
        $maiorGap = [math]::Round($maxDiff, 1)
    } elseif ($sysEvents -and $sysEvents.Count -eq 1) {
        $primeiroLog = $sysEvents[0].TimeCreated.ToString('dd/MM/yyyy HH:mm:ss')
    }

    # Funções de formatação e parser (Aninhadas para não poluir a sessão do usuário)
    function Add-StructuredData {
        param([string]$Title, $Data, [string[]]$KeyProperties)
        $Block = "`n### $Title`n"
        if ($null -eq $Data -or $Data.Count -eq 0) {
            $Block += "[ERRO] Nenhum dado retornado pelo hardware para esta classe.`n"
        } else {
            $Block += "| Propriedade | Valor |`n"
            $Block += "| --- | --- |`n"
            foreach ($prop in $KeyProperties) {
                $value = if ($Data.PSObject.Properties.Match($prop)) { $Data.$prop } else { 'N/A' }
                $Block += "| $prop | $value |`n"
            }
            $Block += "`n"
        }
        [System.IO.File]::AppendAllText($MD, $Block, [System.Text.Encoding]::UTF8)
    }

    function Add-RawData {
        param([string]$Title, $Data)
        $Block = "`n#### Dados Brutos - $Title`n"
        $Block += '```text' + "`n"
        if ($null -eq $Data) {
            $Block += "[ERRO] Nenhum dado retornado pelo hardware para esta classe.`n"
        } else {
            $RawString = $Data | Format-List * | Out-String
            $Block += $RawString.Trim() + "`n"
        }
        $Block += '```' + "`n"
        [System.IO.File]::AppendAllText($MD, $Block, [System.Text.Encoding]::UTF8)
    }

    function Parse-BatteryReport {
        param([string]$ReportPath)
        if (-not (Test-Path $ReportPath)) { return $null }

        $html = Get-Content $ReportPath -Raw
        $parsed = [PSCustomObject]@{
            DesignCapacity = $null
            FullChargeCapacity = $null
            CycleCount = $null
            HealthPercentage = $null
            CapacidadeInicialHistorico = $null
            AlertaDegradacaoOculta = "Não"
        }

        if ($html -match 'Design Capacity.*?(\d+)') { $parsed.DesignCapacity = [int]$matches[1] }
        if ($html -match 'Full Charge Capacity.*?(\d+)') { $parsed.FullChargeCapacity = [int]$matches[1] }
        if ($html -match 'Cycle Count.*?(\d+)') { $parsed.CycleCount = [int]$matches[1] }
        
        if ($parsed.DesignCapacity -and $parsed.FullChargeCapacity) {
            $parsed.HealthPercentage = [math]::Round(($parsed.FullChargeCapacity / $parsed.DesignCapacity) * 100, 2)
        }

        $capacidades = [regex]::Matches($html, '(\d{1,2}[\.,]\d{3})\s*mWh')
        if ($capacidades.Count -gt 2) {
            $primeiraCapacidade = $capacidades[2].Groups[1].Value -replace '[\.,]', ''
            $parsed.CapacidadeInicialHistorico = [int]$primeiraCapacidade

            if ($parsed.FullChargeCapacity -lt ($parsed.CapacidadeInicialHistorico * 0.95) -and $parsed.CycleCount -lt 20) {
                $parsed.AlertaDegradacaoOculta = "SIM (Perda real de capacidade mas contagem de ciclos congelada)"
            }
        }
        return $parsed
    }

    Write-Host '[3/6] Extraindo Telemetria Bruta e Estruturada (WMI/CIM)...' -ForegroundColor Cyan

    $mdBody = "# Relatório de Diagnóstico de Engenharia - Bateria`n`n"
    $mdBody += "- **Data/Hora do Diagnóstico:** $((Get-Date).ToString('dd/MM/yyyy HH:mm:ss'))`n"
    $mdBody += "- **Serial Number (BIOS):** $SN`n"
    $mdBody += "- **Hostname:** $($env:COMPUTERNAME)`n"
    $mdBody += "- **Versão do Script:** 4.5 (Forense de HTML + EVTX)`n`n"
    $mdBody += "---`n`n"

    $mdBody += "## 1. Histórico de Utilização Forense`n"
    $mdBody += "Cruzamento do log do sistema operacional com os dados ACPI para detecção de armazenamento inadequado.`n`n"
    $mdBody += "| Métrica | Resultado |`n"
    $mdBody += "| :--- | :--- |`n"
    $mdBody += "| **Data do Primeiro Uso (OOBE)** | $primeiroLog |`n"
    $mdBody += "| **Maior Intervalo Desligado (Deep Discharge)** | $maiorGap dias consecutivos |`n`n"
    $mdBody += "---`n`n"

    $mdBody += "## 2. Verificação de Integridade do Sistema (PowerCfg)`n"
    $mdBody += "| Comando | Status de Execução |`n"
    $mdBody += "| :--- | :--- |`n"
    $mdBody += "| **powercfg -batteryreport** | $p1_Status |`n"
    $mdBody += "| **powercfg -energy** | $p2_Status |`n`n"
    $mdBody += "---`n`n"
    $mdBody += "## 3. Telemetria Estruturada de Hardware (BMS)`n"

    [System.IO.File]::WriteAllText($MD, $mdBody, [System.Text.Encoding]::UTF8)

    $win32Battery = Get-CimInstance -ClassName Win32_Battery
    Add-StructuredData -Title 'Win32_Battery (CIM Instance - Lógico)' -Data $win32Battery -KeyProperties @('Name', 'Status', 'BatteryStatus', 'EstimatedChargeRemaining', 'EstimatedRunTime', 'DesignCapacity', 'FullChargeCapacity', 'Chemistry', 'TimeToFullCharge', 'TimeOnBattery', 'LastErrorCode')

    $batteryStatus = Get-WmiObject -Class BatteryStatus -Namespace root\wmi
    Add-StructuredData -Title 'BatteryStatus (WMI - Tempo Real)' -Data $batteryStatus -KeyProperties @('Tag', 'PowerOnline', 'Charging', 'Discharging', 'Critical', 'Voltage', 'Current')

    $batteryStatic = Get-WmiObject -Class BatteryStaticData -Namespace root\wmi
    Add-StructuredData -Title 'BatteryStaticData (WMI - Registradores de Fábrica)' -Data $batteryStatic -KeyProperties @('Tag', 'ManufactureName', 'SerialNumber', 'ManufactureDate', 'Chemistry', 'DesignCapacity', 'DesignVoltage')

    $parsedReport = Parse-BatteryReport -ReportPath "$TempFolder\battery-report_$SN.html"
    if ($parsedReport) {
        Add-StructuredData -Title 'Inteligência do Relatório HTML' -Data $parsedReport -KeyProperties @('DesignCapacity', 'FullChargeCapacity', 'CapacidadeInicialHistorico', 'CycleCount', 'HealthPercentage', 'AlertaDegradacaoOculta')
    }

    [System.IO.File]::AppendAllText($MD, "`n---`n`n## 4. Dados Brutos de Hardware (BMS)`n", [System.Text.Encoding]::UTF8)
    Add-RawData -Title 'Win32_Battery' -Data $win32Battery
    Add-RawData -Title 'BatteryStatus' -Data $batteryStatus
    Add-RawData -Title 'BatteryStaticData' -Data $batteryStatic

    Write-Host '[4/6] Extraindo Logs do Sistema (Event Viewer e EVTX)...' -ForegroundColor Cyan

    wevtutil epl System "$EVTX" /overwrite:true

    $mdLogs = "`n---`n`n"
    $mdLogs += "## 5. Relatórios de Eventos do Sistema (Energia e Bateria)`n"
    $mdLogs += "*(Nota: O arquivo .evtx completo está anexado para análise profunda).*`n"
    [System.IO.File]::AppendAllText($MD, $mdLogs, [System.Text.Encoding]::UTF8)

    $activeScheme = powercfg /getactivescheme | Out-String
    $schemeBlock = "`n### Plano de Energia Ativo`n"
    $schemeBlock += '```text' + "`n"
    $schemeBlock += $activeScheme.Trim() + "`n"
    $schemeBlock += '```' + "`n"
    [System.IO.File]::AppendAllText($MD, $schemeBlock, [System.Text.Encoding]::UTF8)

    $events = Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-Kernel-Power','Microsoft-Windows-Battery','Microsoft-Windows-Power-Troubleshooter'} -MaxEvents 50 -ErrorAction SilentlyContinue

    $evtBlock = "`n### Últimos 50 Eventos Críticos`n"
    $evtBlock += "| Data/Hora | ID | Nível | Mensagem |`n"
    $evtBlock += "| --- | --- | --- | --- |`n"

    if ($events) {
        foreach ($evt in $events) {
            $time = $evt.TimeCreated.ToString('dd/MM/yyyy HH:mm:ss')
            $id = $evt.Id
            $level = $evt.LevelDisplayName
            $msg = $evt.Message -replace "`n", " " -replace "`r", " "
            if ($msg.Length -gt 100) { $msg = $msg.Substring(0, 100) + "..." }
            $evtBlock += "| $time | $id | $level | $msg |`n"
        }
    } else {
        $evtBlock += "| N/A | N/A | N/A | Nenhum evento relacionado encontrado. |`n"
    }
    $evtBlock += "`n"
    [System.IO.File]::AppendAllText($MD, $evtBlock, [System.Text.Encoding]::UTF8)

    Write-Host '[5/6] Gerando Arquivo JSON Estruturado...' -ForegroundColor Cyan

    $structuredData = [PSCustomObject]@{
        Timestamp = [DateTime]::Now
        SerialNumber = $SN
        Hostname = $env:COMPUTERNAME
        UsageHistory = [PSCustomObject]@{
            FirstLogDate = $primeiroLog
            MaxIdleDays = $maiorGap
        }
        PowerCfgStatus = [PSCustomObject]@{
            BatteryReport = $p1_Status
            EnergyReport = $p2_Status
        }
        BatteryData = [PSCustomObject]@{
            Win32_Battery = $win32Battery
            BatteryStatus = $batteryStatus
            BatteryStaticData = $batteryStatic
            ParsedReport = $parsedReport
        }
    }

    $structuredData | ConvertTo-Json -Depth 5 | Out-File $JSON -Encoding UTF8

    $mdFooter = "`n---`n"
    $mdFooter += "### Diagnóstico de Alertas`n"
    $mdFooter += "* **Deep Discharge**: Valores acima de 30 dias inativos ($maiorGap detectados) frequentemente causam a oxidação do anodo de lítio, justificando o estufamento mesmo com poucos ciclos.`n"
    $mdFooter += "* **Falso Positivo de Ciclos**: Se a tag *AlertaDegradacaoOculta* estiver como SIM, o BMS do fabricante corrompeu a contagem e está enganando a placa-mãe.`n"

    [System.IO.File]::AppendAllText($MD, $mdFooter, [System.Text.Encoding]::UTF8)

    Write-Host '[6/6] Criando pacote ZIP de auditoria...' -ForegroundColor Cyan
    Compress-Archive -Path "$TempFolder\*" -DestinationPath $ZipFile -Force
    Remove-Item -Path $TempFolder -Recurse -Force

    Write-Host ''
    Write-Host '=== SUCESSO: RELATÓRIO CONCLUÍDO ===' -ForegroundColor Green
    Write-Host "Arquivo salvo na Área de Trabalho: $ZipFile"
    
    Write-Host "`nPressione qualquer tecla para voltar ao menu..."
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
}

function Instalar-Android-Tools {
    Clear-Host
    Write-Host "[!] Configurando ambiente Android..." -ForegroundColor Yellow
    Write-Host "Funcionalidade em desenvolvimento..." -ForegroundColor Gray
    Write-Host "`nPressione qualquer tecla para voltar..."
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
}

# --- LOOP PRINCIPAL ---
do {
    Show-Menu
    $input = Read-Host "Selecione uma opção"

    switch ($input) {
        '1' { Executar-Coleta-Bateria }
        '2' { Write-Host "`nMódulo de Testes em breve..."; Start-Sleep -Seconds 2 }
        '3' { Write-Host "`nLista de Softwares em breve..."; Start-Sleep -Seconds 2 }
        '4' { Instalar-Android-Tools }
        'q' { exit }
        default { Write-Host "`nOpção inválida!" -ForegroundColor Red; Start-Sleep -Seconds 1 }
    }
} while ($true)